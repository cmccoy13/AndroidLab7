package edu.calpoly.rscovil.httpasynctask

import java.util.*

data class Conditions(
    val city : String = "",
    val country : String = "",
    val humidity : String = "",
    val temp : String = "",
    val text : String = ""
)

data class Forecast(
    val code : String = "",
    val date : String = "",
    val day : String = "",
    val high : String = "",
    val low : String = "",
    val text : String = ""
)


data class ForecastService(val query: Query) {
    fun generateConditions() =
        Conditions(query.results.channel.location.city,
            query.results.channel.location.country,
            query.results.channel.atmosphere.humidity,
            query.results.channel.item.condition.temp,
            query.results.channel.item.condition.text)
}

data class Query(val results: Results)

data class Results(val channel: Channel)

data class Channel(val location: Location, val atmosphere: Atmosphere, val item: Item)

data class Location(val city: String, val country: String)

data class Atmosphere(val humidity: String)

data class Item (val condition : Condition, val forecast : List<Forecast>)

data class Condition (val temp: String, val text : String)

