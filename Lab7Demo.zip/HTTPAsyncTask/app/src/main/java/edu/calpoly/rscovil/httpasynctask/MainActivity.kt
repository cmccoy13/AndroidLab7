package edu.calpoly.rscovil.httpasynctask

/* based off example from
    https://grokonez.com/android/kotlin-http-call-with-asynctask-example-android

    --- added support for Gson (check app build.gradle)

    --- created custom Forecast type and nested ForecastService for Gson parsing

    --- eliminated streamToString() and its not-so-elegant null handling

    --- added friendly reminders

    --- added exception handling messages

    --- enter city,country for proper results
*/

import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL


class MainActivity : AppCompatActivity() {

    // Don't forget to enable INTERNET permission in manifest
    //  <uses-permission android:name="android.permission.INTERNET"/>

    val CONNECTON_TIMEOUT_MILLISECONDS = 60000

    val FINE_DONT_USE_GSON = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btGetInfo.setOnClickListener {
            var city = edtCityName.text.toString()
            val url = "https://code.org/schools.json"
            //val url = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22" + city + "%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys"
            GetWeatherAsyncTask().execute(url)
        }
    }

    inner class GetWeatherAsyncTask : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            // Before doInBackground
        }

        override fun doInBackground(vararg urls: String?): String {
            var urlConnection: HttpURLConnection? = null

            try {
                val url = URL(urls[0])

                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.connectTimeout = CONNECTON_TIMEOUT_MILLISECONDS
                urlConnection.readTimeout = CONNECTON_TIMEOUT_MILLISECONDS

                //var inString = streamToString(urlConnection.inputStream)

                // replaces need for streamToString()
                val inString = urlConnection.inputStream.bufferedReader().readText()

                publishProgress(inString)
            } catch (ex: Exception) {
                println("HttpURLConnection exception" + ex)
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect()
                }
            }

            return " "
        }

        override fun onProgressUpdate(vararg values: String?) {
            try {
                if (gsonSwitch.isChecked) {
                    var weatherData = Gson().fromJson(values[0], ForecastService::class.java)
                    val conditions = weatherData.generateConditions()


                    tvWeatherInfo.text =
                            "Location: " + conditions.city + " - " + conditions.country + "\n" +
                            "Humidity: " + conditions.humidity + "\n" +
                            "Temperature: " + conditions.temp + "\n" +
                            "Status: " + conditions.text + "\n" + "GSON!!!"

                    val forecasts = weatherData.query.results.channel.item.forecast

                    for (next in forecasts) {
                        println(next)
                    }

                }
                else {
                    var json = JSONObject(values[0])

                    val schools = json.getJSONObject("schools")
                    val name = schools.getJSONObject("name")
                    /*val channel = results.getJSONObject("channel")

                    val location = channel.getJSONObject("location")
                    val city = location.get("city")
                    val country = location.get("country")

                    val humidity = channel.getJSONObject("atmosphere").get("humidity")

                    val condition = channel.getJSONObject("item").getJSONObject("condition")
                    val temp = condition.get("temp")
                    val text = condition.get("text")*/


                    tvWeatherInfo.text = "Name: " + name
                            //"Location: " + city + " - " + country + "\n" +
                            //"Humidity: " + humidity + "\n" +
                            //"Temperature: " + temp + "\n" +
                            //"Status: " + text
                }
            } catch (ex: Exception) {
                println("JSON parsing exception" + ex.printStackTrace())
            }
        }

        override fun onPostExecute(result: String?) {
            // Done
        }
    }

    // ultimately unnecessary but left in for reference
//    fun streamToString(inputStream: InputStream): String {
//        val bufferReader = BufferedReader(InputStreamReader(inputStream))
//        var line: String
//        var result = ""
//
//        try {
//            do {
//                line = bufferReader.readLine()
//                if (line != null) {
//                    result += line
//                }
//            } while (line != null)
//            inputStream.close()
//        } catch (ex: Exception) {
//            println("InputStream exception" + ex.printStackTrace())
//        }
//
//        return result
//    }
}
