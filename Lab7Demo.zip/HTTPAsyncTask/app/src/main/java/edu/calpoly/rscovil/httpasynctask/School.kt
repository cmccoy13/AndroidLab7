package edu.calpoly.rscovil.httpasynctask

import java.util.*

data class School(
    val name : String = "",
    val city : String = "",
    val state : String = "",
    val zip : String = "",
    val lat : String = "",
    val long : String = ""
)

/*KEEP UPDATING!!*/

data class SchoolService(val query: Query) {
    fun generateSchool() =
        Conditions(query.results.channel.location.city,
            query.results.channel.location.country,
            query.results.channel.atmosphere.humidity,
            query.results.channel.item.condition.temp,
            query.results.channel.item.condition.text)
}

data class Schools(val schools: Schools)

data class name(val name: name)

data class Channel(val location: Location, val atmosphere: Atmosphere, val item: Item)

data class Location(val city: String, val country: String)

data class Atmosphere(val humidity: String)

data class Item (val condition : Condition, val forecast : List<Forecast>)

data class Condition (val temp: String, val text : String)

